-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2021 at 06:37 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `contactmgtsys`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `c_id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(500) DEFAULT NULL,
  `second_name` varchar(255) DEFAULT NULL,
  `work` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`c_id`),
  KEY `FKe07k4jcfdophemi6j1lt84b61` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`c_id`, `description`, `email`, `image`, `name`, `phone`, `second_name`, `work`, `user_id`) VALUES
(18, 'My Dad', 'chetan@gmail.com', 'user.jpg', 'chetan', '9884170224', 'chetan', 'Software Engineer ', 17),
(19, 'My Dad', 'ichetanphalke@gmail.com', 'user.jpg', 'Chetan Phalke', '9284170224', 'chetan', 'Software Engineer ', 17),
(20, 'My Mom', 'kiranchetanphalke@gmail.com', 'user.jpg', 'Kiran Phalke', '9763311202', 'k', 'HoseWife', 17),
(21, 'My Mom', 'kiranchetanphalke@gmail.com', 'Kiran Phalke', 'Kiran Phalke', '9736311202', 'Kiran', 'HoseWife', 17),
(22, 'Dad', 'ichetanphalke@gmail.com', 'ChetanPhalke.jpg', 'ChetanPhalke', '9284170224', 'aba', 'Software Engineer ', 17),
(23, 'My Uncel ', 'bipinbhorpade23@gmail.com', 'Bipin ghorpade.jpg', 'Bipin ghorpade', '9422603220', 'bipin', 'Lecturer', 17),
(24, 'test', 't@gmail.com', 'test testjpeg', 'test test', '985', 't1', 'test', 17),
(25, 'My Grand Father', 'nand@gmail.com', 'Nandkumar Phalke.jpg', 'Nandkumar Phalke', '9850459904', 'nandkumar', 'Farmer', 17),
(26, 'My Grand Mother', 'j@gmail.com', 'jayashri phalke.jpg', 'jayashri phalke', '969699', 'jaya', 'HoseWife', 17),
(27, 'My Attya', 'pp@gmail.com', 'Pradnya Pawar.jpg', 'Pradnya Pawar', '9822886690', 'Aatya', 'Lowyar', 17),
(28, 'My Dada New Numbar', 'chetanphalke@gmail.com', 'Chetan Nand Phalke.jpg', 'Chetan Nand Phalke', '9284170225', 'aaba', 'Software Engineer ', 17),
(36, '', 'ichetanphalke@gmail.com', 'CHETAN N Phalke.jpg', 'CHETAN N Phalke', '9284170224', 'AAho', 'Software Engineer ', 29),
(39, '', 'chet@gmail.com', 'Chetan Phalke.jpg', 'Chetan Phalke', '9860328323', 'chetan', 'software Engineer', 38),
(45, 'my friend', 'chetan7phalke@gmail.com', 'chetan chetan.jpg', 'chetan chetan', '9860328323', 'chetan', 'software Engineer', 44),
(48, 'My Relative', 'kiran@gmail.com', 'Kiran.jpg', 'Kiran', '7418529639', 'Kiran', 'software Engineer', 47);

-- --------------------------------------------------------

--
-- Table structure for table `hibernate_sequence`
--

CREATE TABLE IF NOT EXISTS `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hibernate_sequence`
--

INSERT INTO `hibernate_sequence` (`next_val`) VALUES
(49);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `about` varchar(500) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `enabled` bit(1) NOT NULL,
  `imag_url` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_ob8kqyqqgmefl0aco34akdtpe` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `about`, `email`, `enabled`, `imag_url`, `name`, `password`, `role`) VALUES
(0, 'admin@gmail.com', 'admin@gmail.com', b'1', 'admin', 'admin', 'admin@gmail.com', 'ROLE_ADMIN'),
(6, 'chetan nice						', 'ichetanphalke@gmail.com', b'1', 'Test.jpg', 'Chetan Phalke', 'test', 'ROLE_USER'),
(9, 'kjnjn', 'om@gmail.com', b'1', 'Test.jpg', 'om', 'bjj', 'ROLE_USER'),
(10, 'its Testing', 'imchetanphalke@gmail.com', b'1', 'Test.jpg', 'Chetan Phalke', 't1', 'ROLE_USER'),
(11, 'test', 'imtchetanphalke@gmail.com', b'1', 'Test.jpg', 'Chetan Phalke', 'imt', 'ROLE_USER'),
(14, 'K2@gmail.com', 'k2@gmail.com', b'1', 'Test.jpg', 'kiran', 'K2@gmail.com', 'ROLE_USER'),
(15, 'd@gmail.com', 'd@gmail.com', b'1', 'Test.jpg', 'dnyana', 'd@gmail.com', 'ROLE_USER'),
(16, 'D2@gmail.com', 'd2@gmail.com', b'1', 'Test.jpg', 'dnyanda phalke', 'D2@gmail.com', 'ROLE_USER'),
(17, 'd3@gmial.com', 'd3@gmial.com', b'1', 'Test.jpg', 'dnyanda phalke', '$2a$10$nIhTwtz.bcWIcJxynjOJAOznFg6xG78gHwFQ7AJAPX2uQQYil2kCC', 'ROLE_USER'),
(29, 'kcnp@gmail.com', 'kcnp@gmail.com', b'1', 'Test.jpg', 'kiran phalke', '$2a$10$UpI.U7/3GKPizHnxN5FF9.mbvOEAaiGJl4HjID39t8Br.hO2Zfwam', 'ROLE_USER'),
(37, 'Chetan#111', 'chetanphalke@gmail.com', b'1', 'Test.jpg', 'chetan chetan', '$2a$10$qXVyFb178MfCCwBbIyPOGObDhUZzlf.DcvW7IdIF3Wt3Pyt/Vg00i', 'ROLE_USER'),
(38, 'my Friend 12345678', 'naiminamda@gmail.com', b'1', 'Test.jpg', 'nami inamdar', '$2a$10$C7ScpUIeLfyGBc1PQYQcyOeEks.as6PvXFSSJ9Pfk8DqiySfmjImK', 'ROLE_USER'),
(42, '12345678', '1chetan7phalke@gmail.com', b'1', 'Test.jpg', 'chetan chetan', '$2a$10$c.RUgh1GYyo5PF3DGJK3pelaPyJlQxD6DWCtgpVgeQXUpVNH1S45W', 'ROLE_ADMIN'),
(44, '12345678', 'waghmalemahesh@gmail.com', b'1', 'Test.jpg', 'mahesh', '$2a$10$ZWGWBWMzNlU4.z0OVL0TfuWWA/v9cgzqiVYUHon1Pmt4Qwha9Q/uq', 'ROLE_USER'),
(46, 'Adminadmin', 'chetan7phalke@gmail.com', b'1', 'Test.jpg', 'admin', '$2a$10$KHMyuYbahO4FSulpWSE6ieMH8/spf0zpJUukOuSJVFxkWCbVBzGHG', 'ROLE_ADMIN'),
(47, 'Diploma Student', 'mansinalawade9122@gmail.com', b'1', 'Test.jpg', 'manasi nalawade', '$2a$10$/83ZDT0xd5d0vkYpRH2um.Bg7l8RxkH94AoUxvpi7y7sPTmHRWCN6', 'ROLE_USER');

-- --------------------------------------------------------

--
-- Table structure for table `user_contacts`
--

CREATE TABLE IF NOT EXISTS `user_contacts` (
  `user_id` int(11) NOT NULL,
  `contacts_c_id` int(11) NOT NULL,
  UNIQUE KEY `UK_tj0b5raaaol9ovtb4qv3ckgho` (`contacts_c_id`),
  KEY `FKmo0c5ro6kunnfq71x4bcwb9eh` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_contacts`
--

INSERT INTO `user_contacts` (`user_id`, `contacts_c_id`) VALUES
(17, 18),
(17, 19),
(17, 20),
(17, 21),
(17, 22),
(17, 23),
(17, 24),
(17, 25),
(17, 26),
(17, 27);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `contact`
--
ALTER TABLE `contact`
  ADD CONSTRAINT `FKe07k4jcfdophemi6j1lt84b61` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Constraints for table `user_contacts`
--
ALTER TABLE `user_contacts`
  ADD CONSTRAINT `FKhcgk8d3i757xxnts4pn3cp7cy` FOREIGN KEY (`contacts_c_id`) REFERENCES `contact` (`c_id`),
  ADD CONSTRAINT `FKmo0c5ro6kunnfq71x4bcwb9eh` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
