package com.yellotech.ContactManagementSystem.Entity;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonIgnoreType;


public class Movie {

	

		private int movieId; 
		
		
		private String movieName;
		
		private String movieCatagory;
		
		private int rating;

	
		private User user;
		
		


		public Movie(int movieId, String movieName, String movieCatagory, int rating) {
			super();
			this.movieId = movieId;
			this.movieName = movieName;
			this.movieCatagory = movieCatagory;
			this.rating = rating;
		}


		public Movie() {
			// TODO Auto-generated constructor stub
		}


		public int getMovieId() {
			return movieId;
		}


		public void setMovieId(int movieId) {
			this.movieId = movieId;
		}


		public String getMovieName() {
			return movieName;
		}


		public void setMovieName(String movieName) {
			this.movieName = movieName;
		}


		public String getMovieCatagory() {
			return movieCatagory;
		}


		public void setMovieCatagory(String movieCatagory) {
			this.movieCatagory = movieCatagory;
		}


		public int getRating() {
			return rating;
		}


		public void setRating(int rating) {
			this.rating = rating;
		}

		public User getUser() {
			return user;
		}


		public void setUser(User user) {
			this.user = user;
		}
		
		
		
}
