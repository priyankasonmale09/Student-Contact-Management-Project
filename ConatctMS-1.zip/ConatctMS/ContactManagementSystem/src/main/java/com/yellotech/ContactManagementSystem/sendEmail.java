package com.yellotech.ContactManagementSystem;


import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/* this calsss contains email sending method  this requried <dependency>
<groupId>com.sun.mail</groupId>
<artifactId>javax.mail</artifactId>
<version>1.6.2</version>
</dependency>

*/
public class sendEmail {
	public static void main(String at[]) {

		String message = "Hello this is testing mail";
		String subject = " Testing By Chetan ";
		String from = "ichetanphalke@gmail.com";
		String to = "chetan7phalke@gmail.com";
//		sendEmail(message, subject, from, to);
	}

	private static void sendEmail(String message, String subject, String from, String to) {

//get System Properties
		Properties proparties = System.getProperties();

		proparties.put("mail.smtp.host", "smtp.gmail.com");

		proparties.put("mail.smtp.port", "465");
		proparties.put("mail.smtp.ssl.enable", "true");

		proparties.put("mail.smtp.auth", "true");

			//step 1 get session object

		Session session = Session.getInstance(proparties, new Authenticator() {

			@Override
			protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
				return new javax.mail.PasswordAuthentication("ichetanphalke@gmail.com", "Ichetanphalke#1");

			}
		});

		session.setDebug(true);

			// setp 2 add message

		MimeMessage mail = new MimeMessage(session);
		try {
			// from email
			mail.setFrom(from);
			
			// email to ..
			mail.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			
			// set subject 
			mail.setSubject(subject);
			
			// send Message
			mail.setText(message);
			
			// step 3 send message using transport class
			Transport.send(mail);
			System.out.println("Email Send !!!!!!!!!!!!!!!!!!!!!! ");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
//

	}
}