package com.yellotech.ContactManagementSystem.controllers;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.yellotech.ContactManagementSystem.DAO.contactRepository;
import com.yellotech.ContactManagementSystem.DAO.userRepository;
import com.yellotech.ContactManagementSystem.Entity.Contact;
import com.yellotech.ContactManagementSystem.Entity.User;
import com.yellotech.ContactManagementSystem.helper.Message;

@Controller
@RequestMapping("/user")
public class userController {

	@Autowired
	private userRepository userrepository;

	@Autowired
	private contactRepository contactrepository;

	/* comman dataMethod */
	@ModelAttribute
	public void commanData(Model model, Principal principal) {
		String username = principal.getName();
		User user = userrepository.getUserByUserName(username);
		model.addAttribute("user", user);
	}

	/* default user dashboard */
	@RequestMapping("/")
	public String userDasboard(Model model) {
		model.addAttribute("title", "User DashBoard");
		return "user/userDashboard";
	}

	/* open add New Contact page */
	@GetMapping("/addContact")
	public String addContact(Model model) {
		model.addAttribute("title", "Add Contact");
		model.addAttribute("contact", new Contact());

		return "user/addContact";
	}

	/* addMyContact */

	@PostMapping("/addMyContact")
	public String addMyContact(@Valid @ModelAttribute Contact contact, BindingResult result,
			@RequestParam("profileImage") MultipartFile file, Principal principal, HttpSession session) {
		if (!result.hasErrors()) {
			try {
				String username = principal.getName();
				User user = userrepository.getUserByUserName(username);

				/* processing Nd uploading File */
				if (file.isEmpty()) {

					System.out.println("file is empty");
					contact.setImage("user.jpg");
				} else {
					System.out.println("file is  not empty");
					String cname = contact.getName();

					String grofileExtention = file.getOriginalFilename()
							.substring(file.getOriginalFilename().length() - 4);
					// System.out.println("file Extention ="+grofileExtention);
					contact.setImage(cname.concat(grofileExtention));

					// contact.setImage(file.getOriginalFilename());

					File profile = new ClassPathResource("static/img/").getFile();
					Path path = Paths.get(profile.getAbsolutePath() + "/" + contact.getImage());
					Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

					System.out.println("Image is Uploaded");
				}

				contact.setUser(user);

				user.getContacts().add(contact);

				this.userrepository.save(user);

				session.setAttribute("message",
						new Message("Your Contact Added Scessfully !!!!  You Can Add more...", "success"));
				System.out.println("Data = " + contact);
				System.out.println("Done Data Stored !!!!!!!!!!!!!!!!!!!!!");

			} catch (Exception e) {
				e.printStackTrace();
				session.setAttribute("message", new Message("Something Went Wrong ... Please Try Again ", "danger"));
			}
			return "user/addContact";
		} else {
			System.out.println("validation Error");
			return "user/addContact";
		}

	}

	/*
	 * show my contact Handler with page variable that use shows number of Contact
	 * par page and currant page no
	 */
	@RequestMapping("/showMyContact/{page}")
	public String showMyContact(@PathVariable("page") Integer page, Model model, Principal principal) {
		model.addAttribute("title", "My Contacts");

		Pageable pagable = PageRequest.of(page, 4);

		// String userName=principal.getName();
		User user = this.userrepository.getUserByUserName(principal.getName());
		// List<Contact>
		// contacts=this.contactrepository.findContactByUser(user.getId()); //this is
		// working
		// List<Contact>
		// contacts=this.contactrepository.findContactByUserByOrderByNameAsc(user.getId());
		// // this is also works
		Page<Contact> contacts = this.contactrepository.findContactByUser(user.getId(), pagable);
		model.addAttribute("contacts", contacts);
		model.addAttribute("currentPage", page);
		model.addAttribute("totalPages", contacts.getTotalPages());

		return "user/showMyContact";
	}

	@RequestMapping("/{cId}/contact")
	public String contactDetails(@PathVariable("cId") Integer cId, Model model, Principal principal) {

		Optional<Contact> contactOptional = this.contactrepository.findById(cId);

		Contact contact = contactOptional.get();

		String userName = principal.getName();
		User user = this.userrepository.getUserByUserName(userName);

		if (user.getId() == contact.getUser().getId()) {
			model.addAttribute("contact", contact);
		}
		return "user/contactDetails";
	}

	/* Deleting user specific contacts */
	@GetMapping("/delete/{cId}")
	public String deleteContact(@PathVariable("cId") Integer cId, Model model, Principal principal,
			HttpSession session) {

		Optional<Contact> contactOptional = this.contactrepository.findById(cId);

		Contact contact = contactOptional.get();

		String userName = principal.getName();
		User user = this.userrepository.getUserByUserName(userName);

		if (user.getId() == contact.getUser().getId()) {

			contact.setUser(null);
			this.contactrepository.delete(contact);
			session.setAttribute("message", new Message("Contact Deleted Sucessfully !!!!!", "success"));

		} else {
			session.setAttribute("message",
					new Message("You Dont Have Permission To Delete this Contact .....", "danger"));
		}
		return "redirect:/user/showMyContact/0";
	}

	/* open updateContact Handler */
	@PostMapping("openUpdateContactForm/{cId}")
	public String updateContact(@PathVariable("cId") Integer cId, Model model) {

		Contact contact = this.contactrepository.findById(cId).get();
		model.addAttribute("contact", contact);

		return "user/updateContactForm";
	}

	/* Updating contactDetails */
	@PostMapping("/updateMyContact")
	public String updateMyContact(@Valid @ModelAttribute Contact contact, BindingResult result,
			@RequestParam("profileImage") MultipartFile file, Principal principal, HttpSession session) {
		if (!result.hasErrors()) {

			try {
				Contact oldContactDetails=this.contactrepository.findById(contact.getcId()).get();
				// img
				if(!file.isEmpty()) {
					 //replace img .... del old add new
					//delete
					File deleteProfile = new ClassPathResource("static/img/").getFile();
					File file1=new File(deleteProfile,oldContactDetails.getImage());
					file1.delete();
					//new Upload
		
					String cname = contact.getName();

					String grofileExtention = file.getOriginalFilename()
							.substring(file.getOriginalFilename().length() - 4);
					
					contact.setImage(cname.concat(grofileExtention));
					File profile = new ClassPathResource("static/img/").getFile();
					Path path = Paths.get(profile.getAbsolutePath() + "/" + contact.getImage());
					Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
				
					
					
				}
				else {
					contact.setImage(oldContactDetails.getImage());
				}
				User user=this.userrepository.getUserByUserName(principal.getName());
				contact.setUser(user);
				this.contactrepository.save(contact);
				session.setAttribute("message", new Message("Your Contact Updated Scessdully !!!","success"));
				
			}catch (Exception e) {
				// TODO: handle exception
				System.out.println("Issue in Validation try !!");
				e.printStackTrace();
			}
		}
		

		return "redirect:/user/"+contact.getcId()+"/contact";
		
	}
	
	
/*	User profile   */
	
	@GetMapping("/userProfile")
	public String userProfile(Model model) {
		
		model.addAttribute("title","My Profile Page");
		
		return "/user/userProfile";
	}

}
