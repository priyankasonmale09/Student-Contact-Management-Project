package com.yellotech.ContactManagementSystem.controllers;

import java.util.Random;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.yellotech.ContactManagementSystem.DAO.userRepository;
import com.yellotech.ContactManagementSystem.Entity.User;
import com.yellotech.ContactManagementSystem.emailServices.emailServicessClass;
import com.yellotech.ContactManagementSystem.helper.Message;

@Controller
public class otpController {

	Random random = new Random(1000);

	@Autowired
	private userRepository userrepository;
	
	@Autowired
	private emailServicessClass emailservicessclass;

	@Autowired
	private BCryptPasswordEncoder bcpe;
	
	@GetMapping("/fargotPassword")
	public String fargotPassword() {

		return "fargotPassword";
	}

	// Send on OTP page
	@PostMapping("/sendOTP")
	public String sendOTP(@RequestParam("email") String email , HttpSession session) {
		/* genrateing 4 digit otp */

		int otp = random.nextInt(9999);

		System.out.println("OTP is " + otp);
		String otpMessage="<div style='border : 1px solid #e2e2e2 padding :20px'>"+
						"<h1>Your OTP : <b>"+otp+"</h1></div>";
		/* send otp on email code */
		String subject = "OTP from CMS";

		boolean flag = this.emailservicessclass.sendEmail(subject+String.valueOf(otp), otpMessage, email);
		if (flag) {

			session.setAttribute("systemotp", otp);
			session.setAttribute("email", email);
			return "verifyOTP";
		} else {
				session.setAttribute("message", "PLease Check Yor Mail ID");
				return "/sendOTP";
		}

	}

	// conform check the otp sent on email
	@PostMapping("/conformOTP")
	public String conformOTP(@RequestParam("otp") int otp,HttpSession session) {
	int systemotp=(int)session.getAttribute("systemotp");
	String ueremail=(String)session.getAttribute("email");
	if(systemotp==otp) {
		
	User user=this.userrepository.getUserByUserName(ueremail);
		
	if(user==null) {
	/*	send error msg  */
		session.setAttribute("message", "user does not exiest with this email");
		return "/fargotPassword";
	 	
	}else {
		return "passwordChange";
	}
		// change password handler request
		
	}else {
		session.setAttribute("message", "InValid OTP !!!!!!!");
		return "/fargotPassword";
	}
	
		
	}
	
/*	update new Password */
@PostMapping("/updatePassword")
public String updatePassword(@RequestParam("newPasswprd") String newPassword,HttpSession session) {
	
	String email=(String)session.getAttribute("email");
	User user=this.userrepository.getUserByUserName(email);
	user.setPassword(this.bcpe.encode(newPassword));
	this.userrepository.save(user);
	session.setAttribute("message", new Message("Sucessfully Upated Password  !!!! ", "alert-success"));

	
	
	return "login";	
}
	
	
}
