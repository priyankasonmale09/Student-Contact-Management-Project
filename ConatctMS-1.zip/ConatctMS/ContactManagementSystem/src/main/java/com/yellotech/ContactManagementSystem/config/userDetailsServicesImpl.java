package com.yellotech.ContactManagementSystem.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.yellotech.ContactManagementSystem.DAO.userRepository;
import com.yellotech.ContactManagementSystem.Entity.User;

public class userDetailsServicesImpl implements UserDetailsService{

	@Autowired
	private  userRepository userrepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	/*fetching user from Database*/
		User user=userrepository.getUserByUserName(username);
		
		if(user==null) {
			throw new UsernameNotFoundException("User Name is Not Found");
		}
		
		customUserDetails cust=new customUserDetails(user);
		return cust;
	}

}
