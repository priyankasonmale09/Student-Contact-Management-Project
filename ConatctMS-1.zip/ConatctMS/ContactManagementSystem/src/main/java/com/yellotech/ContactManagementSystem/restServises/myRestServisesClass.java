package com.yellotech.ContactManagementSystem.restServises;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.yellotech.ContactManagementSystem.DAO.userRepository;
import com.yellotech.ContactManagementSystem.Entity.Movie;
import com.yellotech.ContactManagementSystem.Entity.User;


@Service
public class myRestServisesClass {

	@Autowired
	private userRepository userrepository;
	
	@Autowired
	protected RestTemplate restTemplate; 

    protected String serviceUrl="http://localhost:8385/rest/";

  

/* public WebAccountsService(String serviceUrl) {
        this.serviceUrl = serviceUrl.startsWith("http") ?
               serviceUrl : "http://" + serviceUrl;
    }*/

    public myRestServisesClass() {
		super();
		// TODO Auto-generated constructor stub
	}





	public List<Movie> getContactMovies(String accountNumber,Principal principal) {
        
		User user=   this.userrepository.getUserByUserName(principal.getName());
		
		List<Movie> movie = (List<Movie>) restTemplate.getForObject(serviceUrl
                + "{"+user.getEmail()+"}", Movie.class,Movie.class);

        
            return  movie;
    }
	
public List<Movie> getContactMovies1(String email) {
	System.out.println(" -------------------------     in getContactMovies1 of myRestServisesClass");
		User user=   this.userrepository.getUserByUserName("kcnp@gmail.com");
		System.out.println("User Details in myRestServices ------------- "+ user);
	 Movie movie = restTemplate.getForObject(serviceUrl
                + "kcnp@gmail.com", Movie.class);
System.out.println("Contact Site ==   "+movie);
        
            return  (List<Movie>) movie;
    }
	
	
}
