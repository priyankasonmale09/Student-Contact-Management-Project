package com.yellotech.ContactManagementSystem;

import java.util.ArrayList;
import java.util.List;

public class DateDiffrance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int day = 0, month = 5, year = 2021;
		int day1 = 10, month1 = 6, year1 = 2022;
		String startingVar = "Friday";
		String endVar = "";
		DateDiffrance d1 = new DateDiffrance();

		int daysDiffrance = d1.getDatePlus(day, month, year, day1, month1, year1);
		System.out.println(daysDiffrance);

	}

	public int getDatePlus(int day, int month, int year, int day1, int month1, int year1) {
		int count = 0;
		List<String> Daysvar = new ArrayList<String>();
		Daysvar.add("Sunday");
		Daysvar.add("Monday");
		Daysvar.add("Tuesday");
		Daysvar.add("Wenseday");
		Daysvar.add("Thirsday");
		Daysvar.add("Friday");
		Daysvar.add("Sataraday");
int wc=0,m=0,d=0;
		while(year!=year1) {
			wc++;
			System.out.println(" Year Count "+wc+"     "+year);
			while(month!=month1) {
				m++;
				System.out.println("Month Count "+m+"      "+month);
				
				while(day!=day1) {
					d++;
					System.out.println("Date Count "+d+""+day);
					
					day++;
				}
				
				month++;
			}
			
			year++;
		}
		return count;
	}
}
