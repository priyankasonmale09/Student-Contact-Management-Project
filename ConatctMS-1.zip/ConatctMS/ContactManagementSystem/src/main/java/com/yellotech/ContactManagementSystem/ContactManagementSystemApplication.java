package com.yellotech.ContactManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.client.RestTemplate;

import com.yellotech.ContactManagementSystem.config.userDetailsServicesImpl;

@SpringBootApplication
public class ContactManagementSystemApplication {

	@Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
	
	/*@Bean
	public UserDetailsService getUserDetailsService()
	{
		return new userDetailsServicesImpl();
	}
	
	@Bean
	public BCryptPasswordEncoder passwordEncoder()
	{
		return new BCryptPasswordEncoder();
	}
	
	@Bean
	public DaoAuthenticationProvider authonticationProvider()
	{
		DaoAuthenticationProvider daoAuthonticationProvider=new DaoAuthenticationProvider();
		
		daoAuthonticationProvider.setUserDetailsService(this.getUserDetailsService());
		daoAuthonticationProvider.setPasswordEncoder(passwordEncoder());
		
		return daoAuthonticationProvider;
		
	}
*/	
	public static void main(String[] args) {
		SpringApplication.run(ContactManagementSystemApplication.class, args);
	}

}
