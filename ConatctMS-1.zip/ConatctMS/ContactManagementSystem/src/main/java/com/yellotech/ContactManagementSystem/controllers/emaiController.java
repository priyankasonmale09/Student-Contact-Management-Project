package com.yellotech.ContactManagementSystem.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.yellotech.ContactManagementSystem.Entity.emailEntity;
import com.yellotech.ContactManagementSystem.emailServices.emailServicessClass;

@RestController
public class emaiController {

	@Autowired
	private emailServicessClass emailservicesclass;
	
	@RequestMapping(value="/sendemail",method=RequestMethod.POST)
	public ResponseEntity<?> sendEmail(@RequestBody emailEntity request)
	{
		boolean result=this.emailservicesclass.sendEmail(request.getSubject(), request.getMsg(), request.getTo());
		if(result) {
			return ResponseEntity.ok("Mail Send Sccessfully ............");
		}else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Mail Not Send .....");
		}
	
	}
	
}
	/*			   on postman use Url= c
				use JSON object
				{
				  "to":"",
					 "subject":"",
					 "msg":""
				}
		*/		   