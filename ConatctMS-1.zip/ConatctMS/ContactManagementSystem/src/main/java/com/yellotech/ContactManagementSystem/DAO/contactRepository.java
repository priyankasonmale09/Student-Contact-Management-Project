package com.yellotech.ContactManagementSystem.DAO;

import java.util.List;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.yellotech.ContactManagementSystem.Entity.Contact;
import com.yellotech.ContactManagementSystem.Entity.User;

public interface contactRepository extends JpaRepository<Contact, Integer>{
	
	@Query("from Contact as c where c.user.id =:user_id")
	public List<Contact> findContactByUser(@Param("user_id") int user_id);
	
	@Query("from Contact as c where c.user.id =:user_id order by Name asc")
	public List<Contact> findContactByUserByOrderByNameAsc(int user_id);
	//findByLastNameOrderBySeatNumberAsc(String lastName);

	//showing contact in Pagination
	//pagable contains Current page + No of Contacts parpage
	@Query("from Contact as c where c.user.id =:user_id")
	public Page<Contact> findContactByUser(@Param("user_id") int user_id,Pageable pagable);

  /*  search the contact by name containse key as in name  */
	public List<Contact> findByNameContainingAndUser(String name,User user);
	
	
/*	count number of contact of each user */
	/*@Query("count from Contact as c where c.user.id =:user_id")*/
	public int  countByUser(int id);

	/*@Query("count(name) from Contact as c Group By c.user.id ")*/
	@Query("SELECT  COUNT(m)  FROM Contact AS m GROUP BY m.user.id ")
	public List<Integer> coutNameGroupByUserId();
}

