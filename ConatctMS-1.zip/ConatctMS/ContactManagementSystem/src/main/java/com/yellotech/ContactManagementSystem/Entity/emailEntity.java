package com.yellotech.ContactManagementSystem.Entity;

public class emailEntity {

	private String subject;
	private String msg;
	private String to;
	

	public emailEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public emailEntity(String subject, String msg, String to) {
		super();
		this.subject = subject;
		this.msg = msg;
		this.to = to;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	@Override
	public String toString() {
		return "emailEntity [subject=" + subject + ", msg=" + msg + ", to=" + to + "]";
	}	
}
