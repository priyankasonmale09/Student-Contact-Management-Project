package com.yellotech.ContactManagementSystem;

import java.util.ArrayList;
import java.util.List;

public class DateDiffrance1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int day = 1, month = 1, year = 2021, plus = 31;
		String startingVar = "Friday";
		String endVar = "";
		DateDiffrance1 d1 = new DateDiffrance1();

		String newDate = d1.getDatePlus(day, month, year, plus, startingVar);
		System.out.println(newDate);

	}

	public String getDatePlus(int day, int month, int year, int plus, String startingVar) {
		List<String> Daysvar = new ArrayList<String>();
		Daysvar.add("Sunday");
		Daysvar.add("Monday");
		Daysvar.add("Tuesday");
		Daysvar.add("Wenseday");
		Daysvar.add("Thirsday");
		Daysvar.add("Friday");
		Daysvar.add("Sataraday");

		int startDay = 6;
		while (plus != 0) {

			if(month==1||month==3||month==5||month==7||month==8||month==10||month==12) {
				
			System.out.println("this is 31 days month");
			if(day>=31) {
				day=1;
				if (startDay >=7) { // Day Calcumation like SUNDAY MON...
					startDay = 1;

				} else {
					startDay++;
			
				}
				System.out.println("month Cheanged ");
				if(month==12) {
				System.out.println("New Year ");
					year++;	
					month=1;
				}
				else {
				month++;
				
				}
				
			}else {
				day++;
				if (startDay >=7) { // Day Calcumation like SUNDAY MON...
					startDay = 1;

				} else {
					startDay++;
			
				}
				
			}
			
			
			}
			else if(month==2) {
				if(year%4==0) {
					
					System.out.println("Leap Year Is This");
			
					if(day>=29) {
						day=1;
						if (startDay >=7) { // Day Calcumation like SUNDAY MON...
							startDay = 1;

						} else {
							startDay++;
							if (startDay >=7) { // Day Calcumation like SUNDAY MON...
								startDay = 1;

							} else {
								startDay++;
						
							}
					
						}
						month++;
						
					}else {
						day++;
						if (startDay >=7) { // Day Calcumation like SUNDAY MON...
							startDay = 1;

						} else {
							startDay++;
					
						}
						
					}
					
				}else {
					
					System.out.println("This is non leaf Year");
					if(day>=28) {
						System.out.println("month has changed");
						day=1;
						if (startDay >=7) { // Day Calcumation like SUNDAY MON...
							startDay = 1;

						} else {
							startDay++;
					
						}
						month++;
						
					}else {
						day++;
						if (startDay >=7) { // Day Calcumation like SUNDAY MON...
							startDay = 1;

						} else {
							startDay++;
					
						}
						
					}
				}
			}
		
			else {
				System.out.println("this is 30 days month");	
				if(day>=30) {
				
					day=1;
					if (startDay >=7) { // Day Calcumation like SUNDAY MON...
						startDay = 1;

					} else {
						startDay++;
				
					}
					month++;
					
				}else {
					day++;
					if (startDay >=7) { // Day Calcumation like SUNDAY MON...
						startDay = 1;

					} else {
						startDay++;
				
					}
					
					
				}
			}
			
			plus--;
		}
		System.out.println("After Adding That Days Day Will Be = " + Daysvar.get(startDay));

		System.out.println("new Date");
		System.out.println("Day =" + day);
		System.out.println("Month =" + month);
		System.out.println("Year = " + year);
		return " New DATE = " + day + "  / " + month + " / " + year;
		
	}
}
