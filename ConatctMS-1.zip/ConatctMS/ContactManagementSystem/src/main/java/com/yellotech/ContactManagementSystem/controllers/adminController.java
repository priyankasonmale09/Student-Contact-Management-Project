package com.yellotech.ContactManagementSystem.controllers;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.yellotech.ContactManagementSystem.DAO.contactRepository;
import com.yellotech.ContactManagementSystem.DAO.userRepository;
import com.yellotech.ContactManagementSystem.Entity.Contact;
import com.yellotech.ContactManagementSystem.Entity.User;

@Controller
@RequestMapping("/admin")
public class adminController {

	@Autowired
	userRepository userrepository;
	
	@Autowired
	contactRepository contactrepository;
	
	
	/* comman dataMethod */
	@ModelAttribute
	public void commanData(Model model, Principal principal) {
		String username = principal.getName();
		User user = userrepository.getUserByUserName(username);
		model.addAttribute("admin", user);
	}
	
	
	@RequestMapping("/")
	public String adminDashBoard(Model model) {
		
		model.addAttribute("title", "Admin DashBoard");
		
		model.addAttribute("admin",new User());
		return "admin/adminDashboard";
		
	}
	
	/*
	 * show my contact Handler with page variable that use shows number of Contact
	 * par page and currant page no
	 */
	@RequestMapping("/contactListByAllFaculty/{page}")
	public String showMyContact(@PathVariable("page") Integer page, Model model, Principal principal) {
		model.addAttribute("title", "My Contacts");

		Pageable pagable = PageRequest.of(page, 10);

		User user = this.userrepository.getUserByUserName(principal.getName());
		
		
		
		List<Integer> counts = this.contactrepository.coutNameGroupByUserId();
		
		Page <User> users = this.userrepository.findAll(pagable);
		model.addAttribute("noOfContacts", counts);
		//System.out.println("Contact List User Wise No Of Contact are "+counts);
		model.addAttribute("users",users );
		model.addAttribute("currentPage", page);
		model.addAttribute("totalPages", users.getTotalPages());
//System.out.println("Controls Come till second list line of showMyContact() ");
		return "admin/contactListByAllFaculty";
	}
	
	/*
	 * show my contact Handler with page variable that use shows number of Contact
	 * par page and currant page no
	 */
	@RequestMapping("/showThisUserContacts/{id}/{page}")
	public String showThisUserContacts(@PathVariable("id") Integer id,@PathVariable("page") Integer page, Model model, Principal principal , HttpSession session) {
		model.addAttribute("title", "My Contacts");
		Pageable pagable = PageRequest.of(page, 10);

		// String userName=principal.getName();
		//User user = this.userrepository.getUserByUserName(principal.getName());
		
		Optional<User> userOption=userrepository.findById(id);
		
		User user=userOption.get();
		
		Page<Contact> contacts = this.contactrepository.findContactByUser(id, pagable);
		model.addAttribute("user", user);
		model.addAttribute("contacts", contacts);
		model.addAttribute("currentPage", page);
		model.addAttribute("totalPages", contacts.getTotalPages());

		return "admin/showThisUserContacts";
	}
	
	
}
