package com.yellotech.ContactManagementSystem.controllers;

import java.util.Random;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.yellotech.ContactManagementSystem.DAO.userRepository;
import com.yellotech.ContactManagementSystem.Entity.User;
import com.yellotech.ContactManagementSystem.emailServices.emailServicessClass;
import com.yellotech.ContactManagementSystem.helper.Message;

@Controller
public class HomeController {

	@Autowired
	private BCryptPasswordEncoder passEncoder;

	@Autowired
	private userRepository userrepository;

	@Autowired
	private emailServicessClass emailservicessclass;

	@RequestMapping("/")
	public String home(Model model) {
		model.addAttribute("tital", "Home: Contact Management System");
		return "index.html";
	}

	@RequestMapping("/about")
	public String about(Model model) {
		model.addAttribute("tital", "About: Contact Management System");
		return "about.html";
	}

	@RequestMapping("/signup")
	public String signup(Model model) {
		model.addAttribute("tital", "Register: Contact Management System");
		model.addAttribute("user", new User());
		return "signup.html";
	}
	
/*	start new user registration  */
	
@RequestMapping("/regStep1")
public String regStep1(@Valid Model model) {
	model.addAttribute("tital", "Registeration step 1 : Contact Management System");
	return "emailRegistration";
}

	// pre registration email varification step
	@PostMapping("/doEmailValidation")
	public String doEmailValidation(@RequestParam("email") String email, HttpSession session) {

		Random random=new Random();
		
		int otp=random.nextInt(1000);
		System.out.println("OTP is " + otp);
		String otpMessage = "<div style='border : 1px solid #e2e2e2 padding :20px'>" + "<h1>Your OTP : <b>" + otp
				+ "</h1></div>";
		/* send otp on email code */
		String subject = "OTP from CMS for email Varification ";

		boolean flag = this.emailservicessclass.sendEmail(subject + String.valueOf(otp), otpMessage, email);
		if (flag) {

			session.setAttribute("systemotp", otp);
			session.setAttribute("email", email);
			return "verifyEmialOTP";
		} else {
			session.setAttribute("message", "PLease Check Yor Mail ID");
			return "redirect:/regStep1";
		}

//		return "redirect:/doRegistor";
	}

	// conform check the otp sent on email
	@PostMapping("/conformEmailOTP")
	public String conformOTP(@RequestParam("otp") int otp, HttpSession session,Model model) {
		int systemotp = (int) session.getAttribute("systemotp");
	String email=(String)session.getAttribute("email");
	System.out.println("Verifird Email Id Is====================   "+email);
		if (systemotp == otp) {
			//model.addAttribute("email", email);
			User user=new User();
			user.setEmail(email);
			model.addAttribute("user", user);
			return "signup";
		} else {
			session.setAttribute("message", "InValid OTP !!!!!!!");
			return "redirect:/signup";
		}

	}

	// this handler for registring new user
	@PostMapping("/doRegistor")
	public String doRegister(@Valid @ModelAttribute("user") User user, BindingResult result,
			@RequestParam(value = "agreement", defaultValue = "false") boolean agreement, Model model,
			HttpSession session) {
		if (!result.hasErrors()) {
			System.out.println("Agreement : " + agreement);
			user.setEnabled(true);
			user.setRole("ROLE_USER");
			//user.setRole("ROLE_ADMIN");
			user.setImagUrl("Test.jpg");
			System.out.println("Password Encoder = " + passEncoder.encode(user.getPassword()));
			user.setPassword(passEncoder.encode(user.getPassword()));
			try {
				if (!agreement) {
					System.out.println("You have not accepted terms and Condition !");
					throw new Exception("You have not accepted terms and Condition !");
				} else {
					userrepository.save(user);
					model.addAttribute("user", new User());
					session.setAttribute("message", new Message("Sucessfully Registered !!!! ", "alert-success"));
					//return "signin";
				}
				return "login";
			} catch (Exception e) {
				model.addAttribute("user", user);
				session.setAttribute("message",
						new Message("Something Went Wrong !! " + e.getMessage(), "alert-error"));
				e.printStackTrace();
				return "signup";
			}

		} else {
			System.out.println("validation Error");
			return "signup";
		}

	}

	/* login Handler */
	@RequestMapping("/signin")
	public String login() {
		return "login";   
	}
	
}
