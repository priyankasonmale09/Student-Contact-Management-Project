package com.yellotech.ContactManagementSystem.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.yellotech.ContactManagementSystem.Entity.Movie;
import com.yellotech.ContactManagementSystem.restServises.myRestServisesClass;

@RestController
@RequestMapping("/myrest")
public class movieRestAPICallConroller {

	@Autowired
	myRestServisesClass myRestServisesClass;
	
	@RequestMapping("/call/{email}")
	public List<Movie> showMyMovies(@PathVariable("email")String email){
		System.out.println(" in showMyMovies of MovieRestAPICallController");
		List<Movie> movie= myRestServisesClass.getContactMovies1("kcnp@gmail.com");
		if(movie==null) {
			
			System.out.println("Nullllllllllllllllll Moviiiiiiiiiiiiii");
			return null;
		}else {
		
			return movie;
		}
		
		
	}
	
}
