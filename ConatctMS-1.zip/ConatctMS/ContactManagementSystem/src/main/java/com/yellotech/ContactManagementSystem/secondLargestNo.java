package com.yellotech.ContactManagementSystem;

public class secondLargestNo
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

/*//		find 2 highest no 
*/		int x[]= {57,41,38,5,88};

  /*   Frist Way  */

int m=0,s=0;
for(int i=0;i<=x.length-1;i++) {
	if(x[i]>i) {
		m=x[i];
	}
}
System.out.println("m = "+m);
for(int i=0;i<=x.length-1;i++) {
	if(s<x[i]){
		if(x[i]==m) {
		continue;
		}else {
		s=x[i];
		}
	}
}
System.out.println("s = "+s);

 /*  Second Way By Using Bubbal Sort  */

int row=0,col=0,temp=0;;
int max, second;
for(int i=0;i<x.length;i++) {
	for(int j=1;j<(x.length-1);j++) {
		if(x[j-1]>x[j]) {
			temp=x[j-1];
			x[j-1]=x[j];
			x[j]=temp;
		}
	}
}

for( row=0;row<x.length;row++) {
	
	System.out.print(x[row]+" ");
}
System.out.println(" second largest No is = "+(x[x.length-2]));

	}
}
