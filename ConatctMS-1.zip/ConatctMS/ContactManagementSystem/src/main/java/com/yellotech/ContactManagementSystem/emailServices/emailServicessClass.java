package com.yellotech.ContactManagementSystem.emailServices;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Service;

@Service
public class emailServicessClass {

	public boolean sendEmail(String subject, String message, String to) {

		boolean flag = false;
		String from = "kamblepratiksha2810@gmail.com";
		// get System Properties
		Properties proparties = System.getProperties();

		proparties.put("mail.smtp.host", "smtp.gmail.com");

		proparties.put("mail.smtp.port", "465");
		proparties.put("mail.smtp.ssl.enable", "true");

		proparties.put("mail.smtp.auth", "true");

		// step 1 get session object

		Session session = Session.getInstance(proparties, new Authenticator() {

			@Override
			protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
				return new javax.mail.PasswordAuthentication("kamblepratiksha2810@gmail.com", "");

			}
		});

		session.setDebug(true);

		// setp 2 add message

		MimeMessage mail = new MimeMessage(session);
		try {
			// from email
			mail.setFrom(from);

			// email to ..
			mail.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

			// set subject
			mail.setSubject(subject);

			// send Message
		//	mail.setText(message);

			mail.setContent(message, "text/html");
			// step 3 send message using transport class
			Transport.send(mail);
			System.out.println("Email Send !!!!!!!!!!!!!!!!!!!!!! ");
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}
		//
		return flag;
	}

}
