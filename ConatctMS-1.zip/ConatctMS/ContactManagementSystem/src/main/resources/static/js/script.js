console.log("this is costome Script File")

const toggleSideBar = () => {
	
	if($(".sidebar").is(":visible")){
		//true... ie sidebar will close
		$(".sidebar").css("display","none");
		$(".content").css("margin-left","0%");
	}else{
		//fale... ie sidebar will show
		$(".sidebar").css("display","block");
		$(".content").css("margin-left","20%");
	}
	
}

const search=()=>
{
	
//	console.log("Search Method Called");
	let query=$("#search-input").val();
	
	if(query==''){
		
		$(".search-result").hide();
	}else{
		  /* search */
		
	/*	send request to server */
		let url=`http://localhost:8284/search/${query}`;
		
		fetch(url).then((response)=>{
			//console.log(response.json());
			return response.json();
		}).then((data)=>{
			// Data Acces from JSON 
		//	console.log(data);
			
			let text=`<div class='list-group'>`;
				
			data.forEach((contact)=>{
				text+=`<a href='/user/${contact.cId}/contact' class='list-group-item list-group-action'>${contact.name}</a>`;
					});
				text+=`</div>`;
			$(".search-result").html(text);
			$(".search-result").show();
			
		});
		
	}
};